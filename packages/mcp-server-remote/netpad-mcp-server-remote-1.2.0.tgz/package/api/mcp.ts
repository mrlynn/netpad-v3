import type { VercelRequest, VercelResponse } from '@vercel/node';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { IncomingMessage, ServerResponse } from 'node:http';
import { createNetPadMcpServer } from '@netpad/mcp-server';

// Store transports by session ID for reconnection
const transports = new Map<string, StreamableHTTPServerTransport>();

// ============================================================================
// API KEY AUTHENTICATION
// ============================================================================

// Cache validated API keys for 5 minutes to reduce API calls
const apiKeyCache = new Map<string, { valid: boolean; organizationId?: string; expiresAt: number }>();
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Get the NetPad API base URL from environment or default
 */
function getNetPadApiUrl(): string {
  return process.env.NETPAD_API_URL || 'https://netpad.io';
}

/**
 * Validate the API key by calling the NetPad API.
 * Uses the existing NetPad API key validation system.
 *
 * API keys should be in the format: np_live_xxx or np_test_xxx
 *
 * @returns null if valid, or an error response object if invalid
 */
async function validateApiKey(req: VercelRequest): Promise<{ status: number; error: string; code: string } | null> {
  const authHeader = req.headers['authorization'];

  // Check if Authorization header is present
  if (!authHeader) {
    return {
      status: 401,
      error: 'Missing Authorization header. Use: Authorization: Bearer np_live_xxx',
      code: 'MISSING_API_KEY',
    };
  }

  // Check if it's a Bearer token
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') {
    return {
      status: 401,
      error: 'Invalid Authorization header format. Use: Authorization: Bearer np_live_xxx',
      code: 'INVALID_AUTH_FORMAT',
    };
  }

  const apiKey = parts[1].trim();

  if (!apiKey) {
    return {
      status: 401,
      error: 'API key is empty',
      code: 'EMPTY_API_KEY',
    };
  }

  // Validate key format (must start with np_live_ or np_test_)
  if (!apiKey.startsWith('np_live_') && !apiKey.startsWith('np_test_')) {
    return {
      status: 401,
      error: 'Invalid API key format. Keys should start with np_live_ or np_test_. Generate one at netpad.io/settings',
      code: 'INVALID_API_KEY_FORMAT',
    };
  }

  // Check cache first
  const cached = apiKeyCache.get(apiKey);
  if (cached && cached.expiresAt > Date.now()) {
    if (cached.valid) {
      return null; // Valid key from cache
    }
    return {
      status: 401,
      error: 'Invalid or expired API key',
      code: 'INVALID_API_KEY',
    };
  }

  // Validate against NetPad API
  try {
    const netpadUrl = getNetPadApiUrl();
    const response = await fetch(`${netpadUrl}/api/v1/auth/validate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ source: 'mcp-server-remote' }),
    });

    if (response.ok) {
      const data = await response.json();
      // Cache the valid result
      apiKeyCache.set(apiKey, {
        valid: true,
        organizationId: data.organizationId,
        expiresAt: Date.now() + CACHE_TTL_MS,
      });
      return null; // Valid key
    }

    // Key is invalid - cache the negative result too (shorter TTL)
    apiKeyCache.set(apiKey, {
      valid: false,
      expiresAt: Date.now() + 60 * 1000, // Cache invalid keys for 1 minute
    });

    // Parse error response
    const errorData = await response.json().catch(() => ({}));
    return {
      status: response.status,
      error: errorData.error?.message || 'Invalid or expired API key',
      code: errorData.error?.code || 'INVALID_API_KEY',
    };
  } catch (error) {
    console.error('Error validating API key against NetPad:', error);

    // On network error, fall back to format validation only
    // This allows the MCP server to work even if NetPad API is temporarily unavailable
    // but only accepts properly formatted keys
    console.warn('NetPad API unavailable, accepting key based on format validation only');
    return null;
  }
}

// Main handler
export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // ============================================================================
  // AUTHENTICATE REQUEST
  // ============================================================================
  const authError = await validateApiKey(req);
  if (authError) {
    res.status(authError.status).json({
      error: authError.error,
      code: authError.code,
      hint: 'Generate an API key at netpad.io/settings and add it to Claude\'s connector settings under "Advanced settings".',
    });
    return;
  }

  // Get session ID from headers
  const sessionId = req.headers['mcp-session-id'] as string | undefined;

  // Handle GET requests for SSE streams
  if (req.method === 'GET') {
    // For initialization or reconnection
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: () => crypto.randomUUID(),
    });

    // Create the full NetPad MCP server with all 80+ tools
    const server = createNetPadMcpServer({
      name: '@netpad/mcp-server-remote',
      version: '1.1.0',
    });
    await server.connect(transport);

    // Store transport for future requests
    if (transport.sessionId) {
      transports.set(transport.sessionId, transport);
    }

    await transport.handleRequest(
      req as unknown as IncomingMessage,
      res as unknown as ServerResponse
    );
    return;
  }

  // Handle POST requests
  if (req.method === 'POST') {
    // Try to reuse existing transport for this session
    let transport = sessionId ? transports.get(sessionId) : undefined;

    if (!transport) {
      // Create new transport for this request
      transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => crypto.randomUUID(),
      });

      // Create the full NetPad MCP server with all 80+ tools
      const server = createNetPadMcpServer({
        name: '@netpad/mcp-server-remote',
        version: '1.1.0',
      });
      await server.connect(transport);

      if (transport.sessionId) {
        transports.set(transport.sessionId, transport);
      }
    }

    await transport.handleRequest(
      req as unknown as IncomingMessage,
      res as unknown as ServerResponse,
      req.body
    );
    return;
  }

  // Method not allowed
  res.status(405).json({ error: 'Method not allowed' });
}
