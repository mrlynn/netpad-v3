import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(req: VercelRequest, res: VercelResponse) {
  res.status(200).json({
    name: '@netpad/mcp-server-remote',
    version: '1.1.0',
    description: 'NetPad MCP Server - Remote API for Claude Custom Connectors. Includes all 80+ tools from @netpad/mcp-server.',
    endpoints: {
      mcp: '/mcp',
      health: '/health',
    },
    features: {
      tools: '80+ tools',
      categories: [
        'Form Building (6 tools)',
        'Application Management (7 tools)',
        'Marketplace & npm (8 tools)',
        'Workflow Automation (10 tools)',
        'Conversational & Search Forms (11 tools)',
        'Enhanced Templates (5 tools)',
        'Data Browser (12 tools)',
        'Extension Development (5 tools)',
        'Consolidated Reference Tools',
        'Legacy Reference & Helper (16 tools)',
      ],
    },
    authentication: {
      type: 'Bearer token',
      format: 'Authorization: Bearer np_live_xxx',
      generateAt: 'https://netpad.io/settings',
    },
    documentation: 'https://docs.netpad.io/docs/developer/mcp-server',
  });
}
